<?php
/**
 * Copyright © @ 2021 PeopleWare - Paulo Soares All rights reserved.
 * See COPYING.txt for license details.
 */
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Peopleware_Mage2PriceCalc', __DIR__);

